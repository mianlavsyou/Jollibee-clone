﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace LAVA_MA
{
    public partial class BestSellerAllowAccess : Form
    {
        public BestSellerAllowAccess()
        {
            InitializeComponent();
        }
    }
}
