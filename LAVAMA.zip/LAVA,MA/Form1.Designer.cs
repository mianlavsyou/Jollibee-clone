﻿namespace LAVA_MA
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.btnSuperMeals = new System.Windows.Forms.Button();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.btnBurgerSteak = new System.Windows.Forms.Button();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.SidePanel = new System.Windows.Forms.Panel();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.btnJollySpaghetti = new System.Windows.Forms.Button();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btnBurgers = new System.Windows.Forms.Button();
            this.btnChickenJoy = new System.Windows.Forms.Button();
            this.btnBreakfast = new System.Windows.Forms.Button();
            this.btnFamilyMeals = new System.Windows.Forms.Button();
            this.btnNewProduct = new System.Windows.Forms.Button();
            this.btnBestSellers = new System.Windows.Forms.Button();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.nine1 = new LAVA_MA.nine();
            this.eight1 = new LAVA_MA.eight();
            this.seven1 = new LAVA_MA.seven();
            this.six1 = new LAVA_MA.six();
            this.fifth1 = new LAVA_MA.fifth();
            this.fourth1 = new LAVA_MA.fourth();
            this.third1 = new LAVA_MA.third();
            this.second1 = new LAVA_MA.second();
            this.firstCustomer1 = new LAVA_MA.FirstCustomer();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Silver;
            this.panel1.Controls.Add(this.pictureBox17);
            this.panel1.Controls.Add(this.btnSuperMeals);
            this.panel1.Controls.Add(this.pictureBox16);
            this.panel1.Controls.Add(this.btnBurgerSteak);
            this.panel1.Controls.Add(this.pictureBox15);
            this.panel1.Controls.Add(this.SidePanel);
            this.panel1.Controls.Add(this.pictureBox8);
            this.panel1.Controls.Add(this.btnJollySpaghetti);
            this.panel1.Controls.Add(this.pictureBox7);
            this.panel1.Controls.Add(this.pictureBox6);
            this.panel1.Controls.Add(this.pictureBox5);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.btnBurgers);
            this.panel1.Controls.Add(this.btnChickenJoy);
            this.panel1.Controls.Add(this.btnBreakfast);
            this.panel1.Controls.Add(this.btnFamilyMeals);
            this.panel1.Controls.Add(this.btnNewProduct);
            this.panel1.Controls.Add(this.btnBestSellers);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(183, 617);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox17
            // 
            this.pictureBox17.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox17.Image")));
            this.pictureBox17.Location = new System.Drawing.Point(20, 467);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(40, 45);
            this.pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox17.TabIndex = 19;
            this.pictureBox17.TabStop = false;
            // 
            // btnSuperMeals
            // 
            this.btnSuperMeals.FlatAppearance.BorderSize = 0;
            this.btnSuperMeals.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSuperMeals.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuperMeals.ForeColor = System.Drawing.Color.Red;
            this.btnSuperMeals.Location = new System.Drawing.Point(0, 468);
            this.btnSuperMeals.Name = "btnSuperMeals";
            this.btnSuperMeals.Size = new System.Drawing.Size(183, 46);
            this.btnSuperMeals.TabIndex = 18;
            this.btnSuperMeals.Text = "           Super Meals\r\n";
            this.btnSuperMeals.UseVisualStyleBackColor = true;
            this.btnSuperMeals.Click += new System.EventHandler(this.button2_Click);
            // 
            // pictureBox16
            // 
            this.pictureBox16.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox16.Image")));
            this.pictureBox16.Location = new System.Drawing.Point(20, 416);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(40, 45);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox16.TabIndex = 17;
            this.pictureBox16.TabStop = false;
            // 
            // btnBurgerSteak
            // 
            this.btnBurgerSteak.FlatAppearance.BorderSize = 0;
            this.btnBurgerSteak.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBurgerSteak.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBurgerSteak.ForeColor = System.Drawing.Color.Red;
            this.btnBurgerSteak.Location = new System.Drawing.Point(0, 416);
            this.btnBurgerSteak.Name = "btnBurgerSteak";
            this.btnBurgerSteak.Size = new System.Drawing.Size(183, 46);
            this.btnBurgerSteak.TabIndex = 16;
            this.btnBurgerSteak.Text = "             Burger Steak\r\n";
            this.btnBurgerSteak.UseVisualStyleBackColor = true;
            this.btnBurgerSteak.Click += new System.EventHandler(this.btnBurgerSteak_Click);
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox15.Image")));
            this.pictureBox15.Location = new System.Drawing.Point(3, 562);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(33, 18);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox15.TabIndex = 9;
            this.pictureBox15.TabStop = false;
            // 
            // SidePanel
            // 
            this.SidePanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(8)))), ((int)(((byte)(55)))));
            this.SidePanel.Location = new System.Drawing.Point(0, 42);
            this.SidePanel.Name = "SidePanel";
            this.SidePanel.Size = new System.Drawing.Size(10, 46);
            this.SidePanel.TabIndex = 3;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(22, 365);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(40, 45);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 15;
            this.pictureBox8.TabStop = false;
            // 
            // btnJollySpaghetti
            // 
            this.btnJollySpaghetti.FlatAppearance.BorderSize = 0;
            this.btnJollySpaghetti.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnJollySpaghetti.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJollySpaghetti.ForeColor = System.Drawing.Color.Red;
            this.btnJollySpaghetti.Location = new System.Drawing.Point(0, 364);
            this.btnJollySpaghetti.Name = "btnJollySpaghetti";
            this.btnJollySpaghetti.Size = new System.Drawing.Size(183, 46);
            this.btnJollySpaghetti.TabIndex = 14;
            this.btnJollySpaghetti.Text = "             Jolly Spaghetti";
            this.btnJollySpaghetti.UseVisualStyleBackColor = true;
            this.btnJollySpaghetti.Click += new System.EventHandler(this.btnJollySpaghetti_Click);
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(22, 311);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(38, 47);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 13;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(22, 146);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(44, 46);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 3;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(20, 42);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(40, 46);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 12;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(22, 260);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(40, 45);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 11;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(24, 198);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(38, 46);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 10;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(22, 94);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(40, 46);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            // 
            // btnBurgers
            // 
            this.btnBurgers.FlatAppearance.BorderSize = 0;
            this.btnBurgers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBurgers.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBurgers.ForeColor = System.Drawing.Color.Red;
            this.btnBurgers.Location = new System.Drawing.Point(0, 312);
            this.btnBurgers.Name = "btnBurgers";
            this.btnBurgers.Size = new System.Drawing.Size(183, 46);
            this.btnBurgers.TabIndex = 8;
            this.btnBurgers.Text = "  Burgers\r\n";
            this.btnBurgers.UseVisualStyleBackColor = true;
            this.btnBurgers.Click += new System.EventHandler(this.btnBurgers_Click);
            // 
            // btnChickenJoy
            // 
            this.btnChickenJoy.FlatAppearance.BorderSize = 0;
            this.btnChickenJoy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChickenJoy.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChickenJoy.ForeColor = System.Drawing.Color.Red;
            this.btnChickenJoy.Location = new System.Drawing.Point(3, 260);
            this.btnChickenJoy.Name = "btnChickenJoy";
            this.btnChickenJoy.Size = new System.Drawing.Size(180, 46);
            this.btnChickenJoy.TabIndex = 7;
            this.btnChickenJoy.Text = "       Chickenjoy";
            this.btnChickenJoy.UseVisualStyleBackColor = true;
            this.btnChickenJoy.Click += new System.EventHandler(this.btnChickenJoy_Click);
            // 
            // btnBreakfast
            // 
            this.btnBreakfast.FlatAppearance.BorderSize = 0;
            this.btnBreakfast.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBreakfast.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBreakfast.ForeColor = System.Drawing.Color.Red;
            this.btnBreakfast.Location = new System.Drawing.Point(0, 198);
            this.btnBreakfast.Name = "btnBreakfast";
            this.btnBreakfast.Size = new System.Drawing.Size(183, 46);
            this.btnBreakfast.TabIndex = 6;
            this.btnBreakfast.Text = "      Breakfast";
            this.btnBreakfast.UseVisualStyleBackColor = true;
            this.btnBreakfast.Click += new System.EventHandler(this.btnBreakfast_Click);
            // 
            // btnFamilyMeals
            // 
            this.btnFamilyMeals.FlatAppearance.BorderSize = 0;
            this.btnFamilyMeals.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFamilyMeals.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFamilyMeals.ForeColor = System.Drawing.Color.Red;
            this.btnFamilyMeals.Location = new System.Drawing.Point(0, 146);
            this.btnFamilyMeals.Name = "btnFamilyMeals";
            this.btnFamilyMeals.Size = new System.Drawing.Size(183, 46);
            this.btnFamilyMeals.TabIndex = 5;
            this.btnFamilyMeals.Text = "               Family Meals";
            this.btnFamilyMeals.UseVisualStyleBackColor = true;
            this.btnFamilyMeals.Click += new System.EventHandler(this.btnFamilyMeals_Click);
            // 
            // btnNewProduct
            // 
            this.btnNewProduct.FlatAppearance.BorderSize = 0;
            this.btnNewProduct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNewProduct.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewProduct.ForeColor = System.Drawing.Color.Red;
            this.btnNewProduct.Location = new System.Drawing.Point(0, 94);
            this.btnNewProduct.Name = "btnNewProduct";
            this.btnNewProduct.Size = new System.Drawing.Size(183, 46);
            this.btnNewProduct.TabIndex = 4;
            this.btnNewProduct.Text = "           New Product";
            this.btnNewProduct.UseVisualStyleBackColor = true;
            this.btnNewProduct.Click += new System.EventHandler(this.btnDinein_Click);
            // 
            // btnBestSellers
            // 
            this.btnBestSellers.BackColor = System.Drawing.Color.Silver;
            this.btnBestSellers.FlatAppearance.BorderSize = 0;
            this.btnBestSellers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBestSellers.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBestSellers.ForeColor = System.Drawing.Color.Red;
            this.btnBestSellers.Location = new System.Drawing.Point(0, 42);
            this.btnBestSellers.Name = "btnBestSellers";
            this.btnBestSellers.Size = new System.Drawing.Size(183, 46);
            this.btnBestSellers.TabIndex = 3;
            this.btnBestSellers.Text = "         Best Sellers";
            this.btnBestSellers.UseVisualStyleBackColor = false;
            this.btnBestSellers.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(8)))), ((int)(((byte)(55)))));
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(183, 0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(683, 15);
            this.flowLayoutPanel1.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(8)))), ((int)(((byte)(55)))));
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(228, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(110, 124);
            this.panel2.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(13, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Restourents";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(13, 9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(77, 56);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(9, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 19);
            this.label1.TabIndex = 3;
            this.label1.Text = "Fast Foods";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(540, 21);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(23, 19);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 3;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Click += new System.EventHandler(this.pictureBox9_Click);
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.Location = new System.Drawing.Point(595, 21);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(23, 19);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox10.TabIndex = 4;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox11.Image")));
            this.pictureBox11.Location = new System.Drawing.Point(646, 21);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(23, 19);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox11.TabIndex = 5;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox12.Image")));
            this.pictureBox12.Location = new System.Drawing.Point(774, 21);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(23, 19);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox12.TabIndex = 6;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox13.Image")));
            this.pictureBox13.Location = new System.Drawing.Point(829, 21);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(23, 19);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox13.TabIndex = 7;
            this.pictureBox13.TabStop = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox14.Image")));
            this.pictureBox14.Location = new System.Drawing.Point(889, 21);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(23, 19);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox14.TabIndex = 8;
            this.pictureBox14.TabStop = false;
            // 
            // nine1
            // 
            this.nine1.Location = new System.Drawing.Point(183, 128);
            this.nine1.Name = "nine1";
            this.nine1.Size = new System.Drawing.Size(682, 474);
            this.nine1.TabIndex = 17;
            // 
            // eight1
            // 
            this.eight1.Location = new System.Drawing.Point(183, 143);
            this.eight1.Name = "eight1";
            this.eight1.Size = new System.Drawing.Size(682, 474);
            this.eight1.TabIndex = 16;
            // 
            // seven1
            // 
            this.seven1.Location = new System.Drawing.Point(183, 143);
            this.seven1.Name = "seven1";
            this.seven1.Size = new System.Drawing.Size(682, 474);
            this.seven1.TabIndex = 15;
            // 
            // six1
            // 
            this.six1.Location = new System.Drawing.Point(183, 143);
            this.six1.Name = "six1";
            this.six1.Size = new System.Drawing.Size(682, 474);
            this.six1.TabIndex = 14;
            // 
            // fifth1
            // 
            this.fifth1.Location = new System.Drawing.Point(183, 143);
            this.fifth1.Name = "fifth1";
            this.fifth1.Size = new System.Drawing.Size(682, 474);
            this.fifth1.TabIndex = 13;
            // 
            // fourth1
            // 
            this.fourth1.Location = new System.Drawing.Point(183, 143);
            this.fourth1.Name = "fourth1";
            this.fourth1.Size = new System.Drawing.Size(682, 474);
            this.fourth1.TabIndex = 12;
            // 
            // third1
            // 
            this.third1.Location = new System.Drawing.Point(183, 140);
            this.third1.Name = "third1";
            this.third1.Size = new System.Drawing.Size(682, 477);
            this.third1.TabIndex = 11;
            // 
            // second1
            // 
            this.second1.Location = new System.Drawing.Point(183, 137);
            this.second1.Name = "second1";
            this.second1.Size = new System.Drawing.Size(682, 477);
            this.second1.TabIndex = 10;
            // 
            // firstCustomer1
            // 
            this.firstCustomer1.Location = new System.Drawing.Point(183, 128);
            this.firstCustomer1.Name = "firstCustomer1";
            this.firstCustomer1.Size = new System.Drawing.Size(682, 486);
            this.firstCustomer1.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(866, 617);
            this.Controls.Add(this.nine1);
            this.Controls.Add(this.eight1);
            this.Controls.Add(this.seven1);
            this.Controls.Add(this.six1);
            this.Controls.Add(this.fifth1);
            this.Controls.Add(this.fourth1);
            this.Controls.Add(this.third1);
            this.Controls.Add(this.second1);
            this.Controls.Add(this.firstCustomer1);
            this.Controls.Add(this.pictureBox14);
            this.Controls.Add(this.pictureBox13);
            this.Controls.Add(this.pictureBox12);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox9);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.ShowIcon = false;
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnBestSellers;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btnBurgers;
        private System.Windows.Forms.Button btnChickenJoy;
        private System.Windows.Forms.Button btnBreakfast;
        private System.Windows.Forms.Button btnFamilyMeals;
        private System.Windows.Forms.Button btnNewProduct;
        private System.Windows.Forms.Panel SidePanel;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Button btnJollySpaghetti;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.Button btnBurgerSteak;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.Button btnSuperMeals;
        private FirstCustomer firstCustomer1;
        private second second1;
        private third third1;
        private fourth fourth1;
        private fifth fifth1;
        private six six1;
        private seven seven1;
        private eight eight1;
        private nine nine1;
    }
}

